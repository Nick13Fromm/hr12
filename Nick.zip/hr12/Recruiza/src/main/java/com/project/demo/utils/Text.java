package com.project.demo.utils;

public class Text {
	
	public static String getEmailSuccess() {
		String string = "You have successfully passed and is accepted to do the ";
		return string;
	}
	public static String getEmailFail() {
		String string ="Sorry Applicant, we won’t be able to invite you to the next stage of the hiring process.";
		return string;
	}

}
